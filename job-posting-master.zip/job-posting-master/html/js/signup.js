firebase.auth().setPersistence(firebase.auth.Auth.Persistence.SESSION)
  .then(function() {
    // Existing and future Auth states are now persisted in the current
    // session only. Closing the window would clear any existing state even
    // if a user forgets to sign out.
    // ...
    // New sign-in will be persisted with session persistence.
    return firebase.auth().signInWithEmailAndPassword(email, password);
  })
  .catch(function(error) {
    // Handle Errors here.
    var errorCode = error.code;
    var errorMessage = error.message;
  });


function Signup(){

	var email = document.getElementById('email').value;
	var password = document.getElementById('password').value;
  	var passwordc = document.getElementById('passwordc').value;
    var username = document.getElementById('username').value;
    var userschool = document.getElementById('school').value;
    var userprofession = document.getElementById('profession').value;

  if (password == passwordc){
    writeUserData(username,userschool,userprofession)
    window.alert("Succesful!!");
	firebase.auth().createUserWithEmailAndPassword(email, password).catch(function(error) {
	// Handle Errors here.
	var errorCode = error.code;
	var errorMessage = error.message;
	window.alert("Error: " + errorMessage);
	});
	}else{
  window.alert("两次密码输入不一致，请再次确认");
  }



}

function writeUserData(username,userschool,userprofession) {
    var a = firebase.database().ref('users');
    a.once('value').then(function(snapshot){
      var postid = snapshot.val();
      var postData = {
        username:username,
        userschool:userschool,
        userprofession:userprofession
    };
    var newPostKey = firebase.database().ref().child('users').push().key;
    var updates={};
    updates['/users/' + userId + '/' + newPostKey] = postData;
    updates['/users'] = postid;
    return firebase.database().ref().update(updates);
    });
  }
