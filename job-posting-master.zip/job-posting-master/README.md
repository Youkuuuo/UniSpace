# Job-posting
A job posting forum, customers can post part-time and full-time job.

Other customers can upload their Resume,Cover letter.

Author: Andy Liu, Ling Zhi Mo
